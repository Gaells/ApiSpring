package com.example.api_Java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
